import React from 'react';
import logo from '../../logos/Logo.png';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHdd,faPlus,faHome} from '@fortawesome/free-solid-svg-icons'
import { Link, useParams } from 'react-router-dom';


const SideBar = () => {
    return (
        <div>
            <div >
            <Link to='/home'><img  className ='m-2'style={{width: "59px",height: "47px"}} src={logo} alt=""/></Link>
        <Link  style={{textDecoration:'none',color:'black'}} className="d-flex  flex-row m-2">
        <FontAwesomeIcon  className='m-2' icon={faHdd} />
        <p>Booking List </p>
            </Link>  
            <Link style={{textDecoration:'none',color:'black'}}  to='/customerService' className="d-flex  flex-row m-2 ">
        <FontAwesomeIcon className='m-2'  icon={faPlus} />
        <p>Add Rent House</p>
            </Link>   
            <Link style={{textDecoration:'none',color:'black'}}  to='/customerReview' className="d-flex  flex-row  m-2">
        <FontAwesomeIcon className='m-2'  icon={faHome} />
        <p>My Rent</p> 
            </Link>    
        
            </div>
        </div>
    );
};

export default SideBar;